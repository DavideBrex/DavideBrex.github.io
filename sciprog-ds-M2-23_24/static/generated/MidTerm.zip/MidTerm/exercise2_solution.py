"""
Name:
Surname:
ID:
"""

from Bio import SeqIO
import matplotlib.pyplot as plt

def computeKmers(seq, kmerLen, kmerDict):
    """
    given a DNA sequence seq and an integer kmers size kmerLen,
    fills the dictionary kmerDict with all kmers and their multiplicity in the string
    """
    
    if(kmerLen < len(seq)):
        for x in [seq[i:i + kmerLen] for i in range(len(seq) - kmerLen + 1)]:
            if(x in kmerDict):
                kmerDict[x] += 1
            else:
                kmerDict[x] = 1

def parseFasta(fileName,kmerLen):
    """
    reads the fasta file fileName
    constructs the dictionary with all the kmers
    having length kmerLen
    and returns the dictionary 
    """

    cnt = 0
    kmerDict = dict()
    for seq_record in SeqIO.parse(fileName, "fasta"):
        cnt += 1
        seq = str(seq_record.seq)
        computeKmers(seq, kmerLen, kmerDict)
        
    print("Read {} sequences.\nTotal number of {}mers: {}".format(cnt,kmerLen,len(kmerDict)))
    
    return kmerDict

def plotKmerSpectrum(kmerDict):
    """
     Given a dictionary kmerDict (i.e. keys are kmer sequences and 
     values are the number of occurrences of the kmer sequence) plots 
     the kmer spectrum of all the kmers present in the dictionary. 
     The kmer spectrum is a histogram of the multiplicities of all kmers. 
    """

    kmerSpect = dict()
    for k in kmerDict:
        mult = int(kmerDict[k])
        oldVal = kmerSpect.get(mult,0) # get multiplicity, if not found returns 0
        kmerSpect[mult] = oldVal + 1
    
    #print(kmerSpect)
    listMult = list(kmerSpect.keys())
    listMult.sort()
    
    xVals = []
    yVals = []
    for val in listMult:
            xVals.append(val)
            yVals.append(kmerSpect[val])

    plt.plot(xVals,yVals)
    plt.xlabel("Multiplicity")
    plt.ylabel("Occurrences")
    plt.show()
    plt.close()

seq = "AATTAATTAACTAGCCTTAA"
twoMers = dict()
print("sequence:" , seq)
computeKmers(seq, 2, twoMers)
print("twoMers")
print(twoMers)
fourMers = dict()
computeKmers(seq, 4, fourMers)
print("4mers")
print(fourMers)
t2Mers = dict()
computeKmers(seq, 32, t2Mers)
print("32mers")
print(t2Mers)

myFile = "shortSample.fasta"
kmerDict = parseFasta(myFile,4)
print(kmerDict)

myFile = "test_reads_10k.fasta"
kmerDict = parseFasta(myFile,17)
plotKmerSpectrum(kmerDict)
