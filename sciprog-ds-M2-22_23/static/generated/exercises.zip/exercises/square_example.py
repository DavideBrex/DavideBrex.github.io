"""
square example
"""
S = int(input())
AREA = S**2
print("The area of square with size ", S, " is ", AREA)
