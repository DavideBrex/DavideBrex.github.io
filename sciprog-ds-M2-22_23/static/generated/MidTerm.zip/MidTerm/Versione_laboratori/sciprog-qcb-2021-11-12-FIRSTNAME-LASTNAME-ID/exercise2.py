"""
Name:
Surname:
ID:
"""

import mem_limit

from Bio import SeqIO
import matplotlib.pyplot as plt

def computeKmers(seq, kmerLen, kmerDict):
    """
    given a DNA sequence seq and an integer kmers size kmerLen,
    fills the dictionary kmerDict with all kmers and their multiplicity in the string
    """
    raise Exception("TODO IMPLEMENT ME !")


def parseFasta(fileName,kmerLen):
    """
    reads the fasta file : fileName
    constructs the dictionary with all the kmers
    having length kmerLen
    and returns the dictionary 
    """
    raise Exception("TODO IMPLEMENT ME !")

def plotKmerSpectrum(kmerDict):
    """
     Given a dictionary kmerDict (i.e. keys are kmer sequences and 
     values are the number of occurrences of the kmer sequence) plots 
     the kmer spectrum of all the kmers present in the dictionary. 
     The kmer spectrum is a histogram of the multiplicities of all kmers. 
    """
    raise Exception("TODO IMPLEMENT ME !")
    
seq = "AATTAATTAACTAGCCTTAA"
twoMers = dict()
print("sequence:" , seq)
computeKmers(seq, 2, twoMers)
print("twoMers")
print(twoMers)
fourMers = dict()
computeKmers(seq, 4, fourMers)
print("4mers")
print(fourMers)
t2Mers = dict()
computeKmers(seq, 32, t2Mers)
print("32mers")
print(t2Mers)

myFile = "shortSample.fasta"
kmerDict = parseFasta(myFile,4)
print(kmerDict)

# please, uncomment the following lines when parseFasta() works with shortSample.fasta
#myFile = "test_reads_10k.fasta"
#kmerDict = parseFasta(myFile,17)
#plotKmerSpectrum(kmerDict)
