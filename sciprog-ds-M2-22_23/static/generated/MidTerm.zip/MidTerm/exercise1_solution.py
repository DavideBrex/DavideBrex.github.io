"""
Name:
Surname:
ID:
"""

def findPositions(S, S1):
    s1len = len(S1)
    S = S.replace("\n","")
    ret = [x for x in range(0,len(S)) if S[x:x+s1len] == S1]
    if len(ret) > 0:
        print("\nString '{}' found at the following positions:".format(S1))
    else:
        print("\nWarning: string '{}' not found. Returning an empty list.".format(S1))
    return ret


S = """TGAATACATATTATTCCGC
GTCCTACCAAAAAATATACATAGATAT
GATACTAGGGGACCGGTTCCGGGATGA
TGATGATACTAGGGGACCGGTTGATAC"""

print(findPositions(S, "TGA"))
print(findPositions(S, "GAT"))
print(findPositions(S, "none"))
